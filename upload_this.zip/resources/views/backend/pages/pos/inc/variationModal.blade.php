<div class="modal fade" id="productVariationModal" tabindex="-1" aria-labelledby="productVariationLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-4">

            <div class="data-preloader-wrapper d-flex align-items-center justify-content-center min-h-400">
                <div class="" role="status">
                    <span class="sr-only"></span>
                </div>
            </div>

            <div class="product-info">
                {{-- will be populated via ajax call --}}
            </div>
        </div>
    </div>
</div>
