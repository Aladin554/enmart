<div class="modal fade modalParentSelect2" id="pos_customer_modal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content min-h-400">
            <div class="data-preloader-wrapper d-flex align-items-center justify-content-center min-h-400">
                <div class="" role="status">
                    <span class="sr-only"></span>
                </div>
            </div>

            <div class="customer-info">
                {{-- will be populated via ajax call --}}
            </div>
        </div>
    </div>
</div>
