<li>
    <a href="{{ route('admin.appearance.products.index') }}"
        class="{{ areActiveRoutes(['admin.appearance.products.index']) }}">{{ localize('Products Listing') }}</a>
</li>
<li>
    <a href="{{ route('admin.appearance.products.details') }}"
        class="{{ areActiveRoutes(['admin.appearance.products.details']) }}">{{ localize('Product Details') }}</a>
</li>
