<link href="{{ staticAsset('backend/assets/css/main.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ staticAsset('backend/custom/custom.css') }}" rel="stylesheet" type="text/css" />
